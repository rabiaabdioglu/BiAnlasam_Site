<?php 
include "baglan.php";

	$kaydet=$db->prepare("INSERT INTO uye SET
	
        
		sifre =:sifre,
		adi =:adi,
		soyadi =:soyadi,
		cinsiyet =:cinsiyet,
		email =:email
        ");
	$insert=$kaydet->execute(array(
		'sifre' =>$_POST['kayit-sifre'],
		'adi' => $_POST['kayit-ad'],
        'soyadi' => $_POST['kayit-soyad'],
		'cinsiyet' => $_POST['kayit-cins'],
		'email' =>$_POST['kayit-email'],
	
	));

	if ($insert) {

		Header("Location:main.html?durum=ok");

	} else {

		Header("Location:kaydol.html?durum=no");
	}


 ?>