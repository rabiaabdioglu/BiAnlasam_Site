<?php

try{
$db=new PDO("mysql:hos-localhost;dbname=bianlasam;charset=utf8",'root','123456');
}
catch(PDOException $e){
echo  $e=>getMessage("başarısız");
}
?>